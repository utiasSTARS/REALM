from setuptools import setup, find_packages

setup(
    name='dust3r',
    version='0.1',
    packages=find_packages(),
    package_data={'': ['*.so', '*.pyd', '*.dll']}, # Ensure compiled C++ binaries are copied
    include_package_data=True,
)
